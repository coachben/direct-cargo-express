<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

add_action('wp_ajax_softlite_media_upload', 'softlite_media_upload');

function softlite_media_upload() {
    check_ajax_referer('softlite_media_upload_nonce', 'nonce');

    if (!empty($_POST['media_url'])) {
        $url = esc_url_raw($_POST['media_url']);
        $temp_file = download_url($url, 10);

        if (is_wp_error($temp_file)) {
            $response = array(
                'success' => false,
                'message' => 'Failed to download file: ' . $temp_file->get_error_message(),
                'id' => 0,
                'url' => $url,
                'original_url' => $url
            );
        } else {
            $file_array = array(
                'name' => basename($url),
                'tmp_name' => $temp_file
            );

            $file = media_handle_sideload($file_array, 0);

            if (!is_wp_error($file)) {
                $response = array(
                    'success' => true,
                    'message' => 'Media uploaded successfully.',
                    'id' => $file,
                    'url' => wp_get_attachment_url($file),
                    'original_url' => $url
                );
            } else {
                $response = array(
                    'success' => false,
                    'message' => 'Failed to upload file: ' . $file->get_error_message(),
                    'id' => 0,
                    'url' => $url,
                    'original_url' => $url
                );
            }
        }
    } else {
        $response = array(
            'success' => false,
            'message' => 'No media URL provided.'
        );
    }

    wp_send_json($response);
    wp_die();
}