<?php return array('dependencies' => array(), 'version' => '02f39e3cb7d776085f4a');
