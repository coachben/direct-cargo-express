## Release Notes

## Changelog

**Bump Type:** patch

### 🐛 Bug Fixes
- fix: Prevent fatal error when updating options via /wp-admin/options.php  ([#3440](https://github.com/wp-graphql/wp-graphql/pull/3440))

### 👏 Contributors

Thanks to the following contributors for making this release possible:

- [@jasonbahl](https://github.com/jasonbahl)
