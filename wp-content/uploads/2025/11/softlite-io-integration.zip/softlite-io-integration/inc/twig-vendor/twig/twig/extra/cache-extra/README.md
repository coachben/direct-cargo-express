Cache Extension
===============

This package is a Twig extension that provides integration with the Symfony
Cache component.

It provides a single [`cache`][1] tag that allows to cache template fragments.

[1]: https://twig.symfony.com/cache
