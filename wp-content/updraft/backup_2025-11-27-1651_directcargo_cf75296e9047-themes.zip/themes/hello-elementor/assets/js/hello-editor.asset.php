<?php return array('dependencies' => array(), 'version' => '31cbb757b33ef944e875');
