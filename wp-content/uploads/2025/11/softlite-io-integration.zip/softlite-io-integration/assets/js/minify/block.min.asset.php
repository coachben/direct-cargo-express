<?php return array('dependencies' => array('lodash', 'react', 'wp-block-editor', 'wp-components', 'wp-data', 'wp-element', 'wp-i18n', 'wp-primitives'), 'version' => 'a69671e49e4496ae3f9a');
