<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if(!class_exists('\Twig\Environment')){
	require_once(__DIR__ . '/../../twig-vendor/autoload.php');
}

class Softlite_Dynamic_Menu extends \Elementor\Widget_Base {

	public function get_name() {
		return 'softlite_dynamic_menu';
	}

	public function get_title() {
		return esc_html__( 'Dynamic Menu', 'softlite' );
	}

	public function get_icon() {
		return 'eicon-nav-menu';
	}

	public function get_categories() {
		return [ 'softlite' ];
	}

	public function get_keywords() {
		return [ 'menu', 'softlite', 'dynamic' ];
	}

	public function get_style_depends() {
		return [ 
			'softlite-integration-widget-style',
            'elementor-icons-fa-solid', 'elementor-icons-fa-brands', 'elementor-icons-fa-regular'
		];
	}

	public function get_script_depends() {
		return [ 
			'softlite-elementor-widgets-script',
		];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_menu',
            [
                'label' => esc_html__( 'Menu', 'elementor' ),
            ]
		);

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'level',
            [
                'label' => esc_html__( 'Level', 'elementor' ),
                'type' => Elementor\Controls_Manager::SELECT,
                'options' => [
                    'first' => esc_html__( 'First Level', 'elementor' ),
                    'second' => esc_html__( 'Second Level', 'elementor' ),
                ],
                'default' => 'first',
            ]
        );

        $repeater->add_control(
            'text',
            [
                'label' => esc_html__( 'Text', 'elementor' ),
                'type' => Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Menu Item', 'elementor' ),
            ]
        );

        $repeater->add_control(
            'link',
            [
                'label' => esc_html__( 'Link', 'elementor' ),
                'type' => Elementor\Controls_Manager::URL,
                'default' => [
					'url' => '#',
				],
            ]
        );

        $repeater->add_control(
			'custom_css_classes',
			[
				'label' => esc_html__( 'Custom CSS Classes', 'elementor-pro' ),
                'label_block' => true,
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '',
			]
		);

        $this->add_control(
            'menu_items',
            [
                'label' => esc_html__( 'Menu Items', 'elementor' ),
                'type' => Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ text }}}',
            ]
        );

		$this->add_control(
			'dynamic_template',
            [
                'label' => esc_html__( 'Dynamic Template', 'elementor' ),
                'type' => Elementor\Controls_Manager::HIDDEN,
                'language' => 'html',
                'rows' => 20,
                'ai' => [
					'active' => false,
				],
			]
		);

		$this->end_controls_section();
	}

    public function dynamic_render($render) {
		ob_start();

		$settings = $this->get_settings_for_display();

        $render = str_replace('settings.', '', $render);
        
		foreach ($settings as $key => $setting) {
			${$key} = $setting;
		}

		try {
		    eval("?> $render <?php ");;
		} catch (ParseError $e) {
		    echo 'Dynamic Widget Debug: ' . $e->getMessage();
		}

		return ob_get_clean();
	}

    protected function render(): void {
        $settings = $this->get_settings_for_display();

        if ( empty( $settings['dynamic_template'] ) ) {
            return;
        }

        $loader = new \Twig\Loader\ArrayLoader([]);
        $twig = new \Twig\Environment($loader, [
            'debug' => true,
        ]);
        $twig->addExtension(new \Twig\Extension\DebugExtension());
        $render_template = $this->dynamic_render($settings['dynamic_template']);

        if (stripos($render_template, 'Dynamic Widget Debug') === false) {
            try {
                $template = $twig->createTemplate($render_template);
                echo $template->render($settings);
            } catch (\Twig_Error_Syntax $e) {
                $error_message = $e->getMessage();
                $error_message = explode('"', $error_message);

                echo '<pre>';
                echo 'Dynamic Widget Debug: ' . $error_message[0];
                echo '</pre>';
            }
        } else {
            echo '<pre>';
            echo $render_template;
            echo '</pre>';
        }
    }
}